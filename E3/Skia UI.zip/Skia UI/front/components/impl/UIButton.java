package dev.blakejh.vibeclient.newui.front.components.impl;

import dev.blakejh.vibeclient.newui.core.SkiaUI;
import dev.blakejh.vibeclient.newui.core.util.font.FontUtils;
import dev.blakejh.vibeclient.newui.front.components.Component;
import dev.blakejh.vibeclient.util.ColorUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import org.lwjgl.input.Mouse;

import java.awt.*;

public class UIButton extends Component {

    public float radius;
    public Color color;
    public String text;
    public Screen screen;

    public UIButton(float x, float y, float width, float height, float radius, Color color, String text, Screen screen) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.radius = radius;
        this.color = color;
        this.text = text;
        this.screen = screen;
    }

    @Override
    public void render() {
        if(visible) {
            SkiaUI.rrect(x, y, width, height, radius, SkiaUI.paint(color));
            SkiaUI.centeredText(x + (width / 2), y + SkiaUI.textHeight(text, FontUtils.montserratRegular(20)) + 2f, text, FontUtils.montserratRegular(20), SkiaUI.paint(ColorUtil.getSecondaryColorRGB()));

            if(isMouseOver() && Mouse.isButtonDown(0)) {
                MinecraftClient.getInstance().setScreen(screen);
            }
        }
    }
}
