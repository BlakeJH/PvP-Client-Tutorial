package dev.blakejh.vibeclient.newui.front.components.impl;

import dev.blakejh.vibeclient.newui.core.SkiaUI;
import dev.blakejh.vibeclient.newui.front.components.Component;
import dev.blakejh.vibeclient.util.ColorUtil;
import net.minecraft.client.MinecraftClient;

import java.awt.*;

public class ModMenuButton extends Component {

    private String fileName;

    public ModMenuButton(float x, float y, String fileName) {
        this.x = x;
        this.y = y;
        this.width = 70;
        this.height = 70;
        this.fileName = fileName;
    }

    @Override
    public void render() {
        if(MinecraftClient.getInstance().width == 1920) {
            SkiaUI.rrect(x, y, width, height, 15, SkiaUI.paint(ColorUtil.getSecondaryColorRGB()));
            SkiaUI.shadow(x, y, width, height, 15, new Color(0xB3080808, true), 6, 0, 0);
            SkiaUI.vectorImage(x, y, 50, 50, fileName);

        } else {
            SkiaUI.rrect(x, y, width / 2, height / 2, 15 / 2, SkiaUI.paint(ColorUtil.getSecondaryColorRGB()));
            SkiaUI.shadow(x, y, width / 2, height / 2, 15 / 2, new Color(0xB3080808, true), 6, 0, 0);
            SkiaUI.vectorImage(x, y, 50 / 2F, 50 / 2F, fileName);
        }
    }
}
