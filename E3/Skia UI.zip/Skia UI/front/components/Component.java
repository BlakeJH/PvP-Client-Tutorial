package dev.blakejh.vibeclient.newui.front.components;

import dev.blakejh.vibeclient.newui.core.util.MouseUtil;

public abstract class Component {

    public float x, y, width, height;
    public boolean visible = true;

    public abstract void render();

    public void setVisible(boolean visible) {
        this.visible = visible;
    }

    public float getX() {
        return x;
    }

    public float getY() {
        return y;
    }

    public float getWidth() {
        return width;
    }

    public float getHeight() {
        return height;
    }

    public boolean isMouseOver() {
        return MouseUtil.isMouseOver(getX(), getY(), getWidth(), getHeight());
    }
}

