package dev.blakejh.vibeclient.newui.core;

import com.mojang.blaze3d.platform.GlStateManager;
import dev.blakejh.vibeclient.newui.core.state.UIState;
import io.github.humbleui.skija.*;
import lombok.Getter;
import lombok.Setter;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.opengl.GL11;
import java.util.function.Consumer;

@Getter
@Setter
public class SkiaInitializer {
    private static DirectContext context = null;
    private static Surface surface;
    private static BackendRenderTarget renderTarget;

    public static Canvas getCanvas() {
        return surface.getCanvas();
    }

    public static void initialize(int width, int height) {
        if (context == null) {
            context = DirectContext.makeGL();
        }
        createSurface(width, height);
    }

    public static void createSurface(int width, int height) {
        int framebufferObject = MinecraftClient.getInstance().getFramebuffer().fbo;
        renderTarget = BackendRenderTarget.makeGL(width, height, 0, 8, framebufferObject, GL11.GL_RGBA8);
        surface = Surface.makeFromBackendRenderTarget(
                context, renderTarget, SurfaceOrigin.BOTTOM_LEFT, SurfaceColorFormat.RGBA_8888, ColorSpace.getSRGB());
    }

    public static void preFlush() {
        UIState.backup();
        GlStateManager.clearColor(0f, 0f, 0f, 0f);
        if (context != null) {
            context.resetGLAll();
        }

        GL11.glDisable(GL11.GL_ALPHA_TEST);
    }

    public static void flush() {
        if (context != null) {
            context.flush();
        }
        UIState.restore();
    }

    public static void render(Consumer<Canvas> drawingLogic) {
        preFlush();
        Canvas canvas = getCanvas();
        drawingLogic.accept(canvas);
        flush();
    }

    public static void resize(int newWidth, int newHeight) {
        if (surface != null) {
            surface.close();
        }

        if (renderTarget != null) {
            renderTarget.close();
        }
        createSurface(newWidth, newHeight);
    }
}
