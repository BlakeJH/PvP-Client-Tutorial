package dev.blakejh.vibeclient.newui.core.util.font;

import dev.blakejh.vibeclient.newui.core.util.ResourceUtil;
import io.github.humbleui.skija.Data;
import io.github.humbleui.skija.Font;
import io.github.humbleui.skija.Typeface;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

public class FontManager {
    private static final Map<String, Font> fontCache = new HashMap<>();
    private static final Map<String, Typeface> typefaceCache = new HashMap<>();

    private static Typeface getTypeface(String font, FontType type) {
        return typefaceCache.computeIfAbsent(font, k -> loadTypeface(k, type));
    }

    private static Typeface loadTypeface(String font, FontType type) {
        Optional<Data> fontDataOptional = ResourceUtil.convertToData("/assets/clientname/fonts/" + font);
        return fontDataOptional
                .map(Typeface::makeFromData)
                .orElseThrow(() -> new IllegalArgumentException("Font not found: " + font));
    }

    public static Font font(String font, float size, FontType fontType) {
        String key = font + "-" + size;
        return fontCache.computeIfAbsent(key, k -> new Font(getTypeface(font, fontType), size));
    }

    public static Font font(String font, float size) {
        return font(font, size, getFontType(font)); // Automatically detect font type
    }

    private static FontType getFontType(String font) {
        String fileExtension = font.substring(font.lastIndexOf('.') + 1).toLowerCase();
        return FontType.fromString(fileExtension);
    }
}
