package dev.blakejh.vibeclient.newui.core.util.font;

import io.github.humbleui.skija.Font;

public class FontUtils {

    public static Font montserratBold(float size) {
        return FontManager.font("bold.ttf", size);
    }

    public static Font montserratExtraBold(float size) {
        return FontManager.font("extrabold.ttf", size);
    }

    public static Font montserratExtraLight(float size) {
        return FontManager.font("extralight.ttf", size);
    }

    public static Font montserratLight(float size) {
        return FontManager.font("light.ttf", size);
    }

    public static Font montserratMedium(float size) {
        return FontManager.font("medium.ttf", size);
    }

    public static Font montserratRegular(float size) {
        return FontManager.font("regular.ttf", size);
    }

    public static Font montserratSemiBold(float size) {
        return FontManager.font("semibold.tff", size);
    }

    public static Font montserratThin(float size) {
        return FontManager.font("thin.ttf", size);
    }
}
