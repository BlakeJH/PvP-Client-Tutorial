package dev.blakejh.vibeclient.newui.core.util.font;

import lombok.Getter;

@Getter
public enum FontType {
    TTF("ttf"),
    OTF("otf");

    private final String string;

    FontType(String string) {
        this.string = string;
    }

    public static FontType fromString(String extension) {
        // Normalize the extension to lower case to handle different casing
        String normalizedExtension = extension.toLowerCase();
        return switch (normalizedExtension) {
            case "ttf" -> TTF;
            case "otf" -> OTF;
            default -> throw new IllegalArgumentException("Unsupported font type: " + extension);
        };
    }

    @Override
    public String toString() {
        return string;
    }
}
