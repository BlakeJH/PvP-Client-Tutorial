package dev.blakejh.vibeclient.newui.core.util;

import io.github.humbleui.skija.Data;

import javax.imageio.ImageIO;
import javax.imageio.stream.ImageInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Optional;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ResourceUtil {
    private static final Logger LOGGER = Logger.getLogger(ResourceUtil.class.getName());

    public static Optional<byte[]> convertToBytes(String path) {
        try (InputStream inputStream = getResourceAsStream(path)) {
            return Optional.of(inputStream.readAllBytes());
        } catch (IOException e) {
            LOGGER.log(Level.SEVERE, "Failed to read bytes from resource: " + path, e);
            return Optional.empty();
        }
    }

    public static Optional<Data> convertToData(String path) {
        return convertToBytes(path).map(Data::makeFromBytes);
    }

    public static Optional<ImageInputStream> convertToImageInputStream(String resourceName) {
        try (InputStream stream = getResourceAsStream(resourceName)) {
            return Optional.of(ImageIO.createImageInputStream(stream));
        } catch (IOException e) {
            LOGGER.log(Level.SEVERE, "Failed to create ImageInputStream for resource: " + resourceName, e);
            return Optional.empty();
        }
    }

    public static InputStream getResourceAsStream(String path) {
        InputStream inputStream = ResourceUtil.class.getResourceAsStream(path);
        if (inputStream == null) {
            throw new IllegalArgumentException("Resource not found: " + path);
        }
        return inputStream;
    }

    public static InputStream getFileAsStream(String filePath) throws IOException {
        Path path = Paths.get(filePath);
        return Files.newInputStream(path);
    }
}
