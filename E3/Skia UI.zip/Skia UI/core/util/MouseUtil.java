package dev.blakejh.vibeclient.newui.core.util;

import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.Display;

public class MouseUtil {

    public static boolean isMouseOver(float x, float y, float width, float height) {
        float mouseX = Mouse.getX();
        float mouseY = Display.getHeight() - Mouse.getY();
        return mouseX >= x && mouseY >= y && mouseX < x + width && mouseY < y + height;
    }

    public static float getMouseX() {
        return Mouse.getX();
    }

    public static float getMouseY() {
        return Display.getHeight() - Mouse.getY();
    }

}
