package dev.blakejh.vibeclient.newui.core.ui.util;

import org.lwjgl.opengl.Display;

public class UIWindowBuilder {
    private float x;      // The X coordinate of the window
    private float y;      // The Y coordinate of the window
    private float width;  // The width of the window
    private float height; // The height of the window
    private boolean center = false;  // Whether to center the window on the screen

    public UIWindowBuilder width(float width) {
        this.width = width;
        return this;
    }

    public UIWindowBuilder height(float height) {
        this.height = height;
        return this;
    }

    public UIWindowBuilder position(float x, float y) {
        this.x = x;
        this.y = y;
        return this;
    }

    public UIWindowBuilder centerOnScreen() {
        this.center = true;
        return this;
    }

    public UIWindow build() {
        if (center) {
            x = (float) Display.getWidth() / 2.0f - width / 2.0f;
            y = (float) Display.getHeight() / 2.0f - height / 2.0f;
        }
        return new UIWindow(x, y, width, height);
    }
}
