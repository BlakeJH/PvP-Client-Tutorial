package dev.blakejh.vibeclient.newui.core.ui;

import dev.blakejh.vibeclient.newui.core.SkiaInitializer;
import net.minecraft.client.gui.screen.Screen;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.Display;

public abstract class UIScreen extends Screen {

    public abstract void renderUI(float mouseX, float mouseY);

    public abstract void mousePressed(float mouseX, float mouseY, int mouseButton);

    public abstract void mouseReleased(float mouseX, float mouseY);

    @Override
    public void render(int mouseX, int mouseY, float tickDelta) {
        super.render(mouseX, mouseY, tickDelta);
        SkiaInitializer.render((context) -> this.renderUI((float) Mouse.getX(), (float) Display.getHeight() - Mouse.getY()));
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) {
        this.mousePressed((float) Mouse.getX(), (float) Display.getHeight() - Mouse.getY(), mouseButton);
    }

    @Override
    protected void mouseReleased(int mouseX, int mouseY, int state) {
        this.mouseReleased((float) Mouse.getX(), (float) Display.getHeight() - Mouse.getY());
    }
}
