package dev.blakejh.vibeclient.newui.core;

import dev.blakejh.vibeclient.file.FileManager;
import dev.blakejh.vibeclient.ui.core.util.font.FontUtils;
import io.github.humbleui.skija.Canvas;
import io.github.humbleui.skija.Font;
import io.github.humbleui.skija.Image;
import io.github.humbleui.skija.Paint;
import io.github.humbleui.skija.*;
import io.github.humbleui.skija.svg.SVGDOM;
import io.github.humbleui.types.RRect;
import io.github.humbleui.types.Rect;

import java.awt.Color;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public class SkiaUI {

    private static Canvas getCanvas() {
        return SkiaInitializer.getCanvas();
    }

    public static float text(float x, float y, String text, Font font, Paint paint) {
        Rect bounds = font.measureText(text);
        getCanvas().drawString(text, x - 2f, (y - 2f) + bounds.getHeight(), font, paint);
        return bounds.getHeight();
    }

    public static float centeredText(float x, float y, String text, Font font, Paint paint) {
        Rect measure = font.measureText(text);
        return text(x - measure.getWidth() / 2f, y - measure.getHeight() / 2f, text, font, paint);
    }

    public static Paint paint(Object color) {
        Paint paint = new Paint();
        if (color instanceof Color4f) {
            paint.setColor4f((Color4f) color);
        } else if (color instanceof Color) {
            Color c = (Color) color;
            paint.setARGB(c.getAlpha(), c.getRed(), c.getGreen(), c.getBlue());
        }
        return paint;
    }

    public static float textWidth(String text, Font font) {
        return font.measureTextWidth(text);
    }

    public static float textHeight(String text, Font font) {
        return font.measureText(text).getHeight();
    }

    public static void rrect(float x, float y, float w, float h, float radius, Paint paint) {
        getCanvas().drawRRect(RRect.makeXYWH(x, y, w, h, radius), paint);
    }

    private static int colorToArgb(Color color) {
        return (color.getAlpha() << 24) | (color.getRed() << 16) | (color.getGreen() << 8) | color.getBlue();
    }

    public static void gradientRRect(float x, float y, float w, float h, float radius, Color startColor, Color endColor) {
        int[] colors = new int[]{
                colorToArgb(startColor),
                colorToArgb(endColor)
        };

        float[] positions = {0.0f, 1.0f};

        Shader gradient = Shader.makeLinearGradient(x, y, x, y + h, colors, positions, GradientStyle.DEFAULT);
        Paint gradientPaint = new Paint().setShader(gradient);
        getCanvas().drawRRect(RRect.makeXYWH(x, y, w, h, radius), gradientPaint);
    }

    public static void shadow(float x, float y, float w, float h, float radius, Color color, float blur, float offsetX, float offsetY) {
        getCanvas().drawRectShadow(RRect.makeXYWH(x, y, w, h, radius), offsetX, offsetY, blur, 1f, color.getRGB());
    }

    public static void simpleShadow(float x, float y, float w, float h, float radius, Color color) {
        getCanvas().drawRectShadow(RRect.makeXYWH(x, y, w, h, radius), 0f, 0f, 10f, 1f, color.getRGB());
    }

    public static void rect(float x, float y, float w, float h, Paint paint) {
        getCanvas().drawRect(Rect.makeXYWH(x, y, w, h), paint);
    }

    public static String truncateText(String text, float maxWidth, Font font) {
        if (SkiaUI.textWidth(text, font) <= maxWidth) {
            return text;
        }

        while (SkiaUI.textWidth(text + "...", font) > maxWidth) {
            text = text.substring(0, text.length() - 1);
        }
        return text + "...";
    }

    public static void rasterImage(float x, float y, float width, float height, String fileName) {
        try {

            Path filePath = FileManager.IMG_DIR.toPath().toAbsolutePath().resolve(fileName);

            byte[] data = Files.readAllBytes(filePath);
            Image image = Image.makeDeferredFromEncodedBytes(data);
            Rect imgRect = Rect.makeXYWH(x, y, width, height);

            getCanvas().drawImageRect(image, imgRect, (Paint) null);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public static void vectorImage(float x, float y, float width, float height, String fileName) {
        Path filePath = FileManager.IMG_DIR.toPath().toAbsolutePath().resolve(fileName);

        try {
            byte[] data = Files.readAllBytes(filePath);

            SVGDOM svg = new SVGDOM(Data.makeFromBytes(data));
            svg.setContainerSize(width, height);

            getCanvas().save();
            getCanvas().translate(x, y);

            svg.render(getCanvas());

            getCanvas().restore();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

