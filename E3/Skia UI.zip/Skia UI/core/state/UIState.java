package dev.blakejh.vibeclient.newui.core.state;

import java.util.Stack;

public class UIState {

    // Stack to manage multiple UI states
    private static final Stack<State> stateStack = new Stack<>();

    /**
     * Backs up the current OpenGL state and pushes it onto the stack.
     */
    public static void backup() {
        State currentState = new State();
        currentState.backupCurrentState();
        stateStack.push(currentState);
    }

    /**
     * Restores the most recent OpenGL state from the stack.
     */
    public static void restore() {
        if (!stateStack.isEmpty()) {
            State previousState = stateStack.pop();
            previousState.restorePreviousState();
        }
    }
}
